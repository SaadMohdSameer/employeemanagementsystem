package com.ems.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ems.entities.Manager;
import com.ems.service.ManagerService;
import java.util.List;

@RestController
public class ManagerController {

    @Autowired
    private ManagerService managerService;

    @GetMapping("/getAllManagers")
    public List<Manager> getAllManagers() {
        return this.managerService.getAllManagers();
    }
    @GetMapping("/getManagerById/{id}") 
    public void getManagerById(@PathVariable int id) {
    	managerService.getManagerById(id);
    }

    @PostMapping("/addManager")
    public void addManager(@RequestBody Manager manager) {
        this.managerService.addManager(manager);
    }
    @DeleteMapping("/deleteManagerById")
    public void deleteManagerByID(@PathVariable int id) {
    	managerService.deleteManagerById(id);
    }
    // Add other methods as needed for Manager operations
}
