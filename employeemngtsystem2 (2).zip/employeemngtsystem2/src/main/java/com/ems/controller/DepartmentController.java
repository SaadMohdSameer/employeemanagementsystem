package com.ems.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ems.entities.Department;
import com.ems.service.DepartmentService;
import java.util.List;

@RestController
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;

    @GetMapping("/getAllDepartments")
    public List<Department> getAllDepartments() {
        return this.departmentService.getAllDepartments();
    }
    @GetMapping("/getDepartmentById/{id}")
    public void getDepartmentById(@PathVariable int id) {
    	departmentService.getDepartmentById(id);
    }

    @PostMapping("/addDepartment")
    public void addDepartment(@RequestBody Department department) {
        this.departmentService.addDepartment(department);
    }
    @PutMapping("/updateDepartmentById/{id}")
    public void updateDepartment(@RequestBody Department department) {
    	departmentService.updateDepartmentById(department);
    }
    
    @DeleteMapping("/deleteDepartment/{id}")
    public void deleteDepartmentById(@PathVariable int id) {
    	departmentService.deleteDepartmentById(id);
    }
    // Add other methods as needed for Department operations
}
