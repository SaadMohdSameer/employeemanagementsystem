package com.ems.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ems.converter.EmployeeConverter;
import com.ems.dto.EmployeeDTO;
import com.ems.entities.Employee;
import com.ems.service.EmployeeService;
@RestController
public class EmployeeController {
	@Autowired
	private EmployeeService es;

	@GetMapping("/getallemployee")
	public List<Employee> getallemployee() {
		return this.es.getallEmployees();
	}

	@GetMapping("/test")
	@ResponseBody
	public String test() {
		return "test for testing";

	}
	@GetMapping("/getEmployeeById/{id}")
	public void getEmployeeById(@PathVariable int id) {
		es.getEmployeeById(id);
	}

	/*@GetMapping("/getEmployee")
	public Employee getEmployee() {
		Employee e = new Employee();
		e.setEmpid(1616);
		e.setEmpname("Sam");
		e.setEmpcity("Darbhanga");
		e.setEmpmoblie("8092834997");
		e.setEmpmail("saadmdsameer@gmail.com");
		return e;
	}*/

	@PostMapping("/addEmployee/")
	public void addEmployee(@RequestBody Employee e) {
		es.addEmployee(e);

	}
//	@Autowired
//	private EmployeeConverter employeeconverter;
//	
//	@PostMapping("/addEmployee")
//	ResponseEntity<EmployeeDTO> addEmployee(@RequestBody EmployeeDTO employeeDTO)
//	{
//		 final Employee employee = employeeconverter.convertToEmployeeEntity(employeeDTO);
//		   
//	       //return new ResponseEntity<>(es.addEmployee(employee), HttpStatus.CREATED);
//	    } 	
	@PutMapping("/updateEmployeeById/{id}")
	public void updateEmployeeById(@RequestBody Employee e) {
		es.updateEmployeeById(e);
	}
	
	
	
	@DeleteMapping("/deleteEmployeeById/{id}")
	public void deleteEmployeeById(@PathVariable int id) {
		es.deleteEmployeeById(id);
		
	}
	@DeleteMapping("/deleteAllEmployee")
	public void deleteAllEmployee() {
		es.deleteAllEmployee();
		
	}

}
