package com.ems;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Employeemngtsystem2Application {

	public static void main(String[] args) {
		SpringApplication.run(Employeemngtsystem2Application.class, args);
	System.out.println("welcome to Employee Management System");
	}

}
