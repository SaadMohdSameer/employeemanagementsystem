package com.ems.converter;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.ems.dto.ManagerDTO;
import com.ems.entities.Manager;

@Component
public class ManagerConverter {

    public Manager convertToManagerEntity(ManagerDTO managerDTO) {
        Manager manager = new Manager();
        if (managerDTO != null) {
            BeanUtils.copyProperties(managerDTO, manager);
        }
        return manager;
    }

    public ManagerDTO convertToManagerDTO(Manager manager) {
        ManagerDTO managerDTO = new ManagerDTO();
        if (manager != null) {
            BeanUtils.copyProperties(manager, managerDTO);
        }
        return managerDTO;
    }
}
