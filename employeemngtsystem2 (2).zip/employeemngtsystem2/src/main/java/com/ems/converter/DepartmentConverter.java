package com.ems.converter;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.ems.dto.DepartmentDTO;
import com.ems.entities.Department;

@Component
public class DepartmentConverter {

    public Department convertToDepartmentEntity(DepartmentDTO departmentDTO) {
        Department department = new Department();
        if (departmentDTO != null) {
            BeanUtils.copyProperties(departmentDTO, department);
        }
        return department;
    }

    public DepartmentDTO convertToDepartmentDTO(Department department) {
        DepartmentDTO departmentDTO = new DepartmentDTO();
        if (department != null) {
            BeanUtils.copyProperties(department, departmentDTO);
        }
        return departmentDTO;
    }
}
