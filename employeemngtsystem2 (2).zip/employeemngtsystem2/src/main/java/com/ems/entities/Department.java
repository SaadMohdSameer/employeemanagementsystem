package com.ems.entities;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Department {
    @Id
    private int departmentId;
    private String departmentName;
    private String departmentLocation;
    // Add any other fields or relationships as needed
}
