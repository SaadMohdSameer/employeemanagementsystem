package com.ems.entities;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Manager {
    @Id
    private int managerId;
    private String managerName;
    private String managerCity;
    private String managerMobile;
    private String managerEmail;
    // Add any other fields or relationships as needed
}