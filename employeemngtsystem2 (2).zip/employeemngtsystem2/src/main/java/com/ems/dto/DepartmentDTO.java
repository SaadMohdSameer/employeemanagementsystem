package com.ems.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DepartmentDTO {
	private int departmentid;
	private String department;
	private String departmentLocation;

}
