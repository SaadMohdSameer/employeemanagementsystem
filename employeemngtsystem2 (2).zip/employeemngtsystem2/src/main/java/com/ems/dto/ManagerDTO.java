package com.ems.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ManagerDTO {
	private int managerId;
	private String managerName;
	private String managercity;
	private String managerMobile;
	private String managerEmail;

}
