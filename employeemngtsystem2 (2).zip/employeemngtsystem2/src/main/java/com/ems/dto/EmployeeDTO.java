package com.ems.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter

public class EmployeeDTO {
	private int empid;
	private String empname;
	private String empcity;
	private String empmoblie;
	private String empmail;
}
