package com.ems.repository;

import java.beans.JavaBean;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.ems.entities.Manager;
@JavaBean
@Component
public interface ManagerRepository extends JpaRepository<Manager, Integer> {

}
