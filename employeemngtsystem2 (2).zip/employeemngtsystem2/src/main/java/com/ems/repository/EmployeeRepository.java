package com.ems.repository;
import java.beans.JavaBean;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.ems.entities.Employee;

@JavaBean
@Component
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

}
