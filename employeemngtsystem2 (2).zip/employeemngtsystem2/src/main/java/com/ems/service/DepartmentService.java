package com.ems.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ems.entities.Department;
import com.ems.repository.DepartmentRepository;
import java.util.List;

@Service
public class DepartmentService {

    @Autowired
    private DepartmentRepository departmentRepository;

    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }
    public void getDepartmentById(int id) {
    	departmentRepository.findById(id);
    }

    public void addDepartment(Department department) {
        departmentRepository.save(department);
    }
    public void updateDepartmentById(Department department) {
    	departmentRepository.save(department);
    }
    public void deleteDepartmentById(int id) {
    	departmentRepository.deleteById(id);
    }
    // Add other methods as needed for Department operations
}

