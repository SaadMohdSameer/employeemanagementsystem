package com.ems.service;

//import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.ems.entities.Employee;
import com.ems.repository.EmployeeRepository;
@Service
public class EmployeeService {
	@Autowired
	EmployeeRepository er;
//	private static List<Employee> Le = new ArrayList<>();
//	static {
//		Le.add(new Employee(123, "Micky", "Delhi", "9468469796", "Sachin@123"));
//		Le.add(new Employee(456, "Sam", "Gao", "9746465871", "Sam@786"));
//		Le.add(new Employee(1616, "Pinky", "Gurgaon", "8860738892", "Pinky@1616"));
//		Le.add(new Employee(1010, "Ravi", "Khera", "7503282869", "Ravi@1010"));
//		Le.add(new Employee(247, "Sachin", "Paris", "9718469796", "Sachin@2407"));
//	}
	public void getEmployeeById(int id) {
		er.findById(id);
	}

	public List<Employee> getallEmployees() {
		return er.findAll();
	}

	public void addEmployee(Employee e) {
		er.save(e);

	}
	public void updateEmployeeById(Employee e) {
		er.save(e);
	}
    public void deleteEmployeeById(int id) {
    	er.deleteById(id);
    }
    public void deleteAllEmployee() {
    	er.deleteAll();
    }
}

